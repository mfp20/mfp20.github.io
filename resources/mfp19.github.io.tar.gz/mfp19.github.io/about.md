---
layout: page
title: About Me
permalink: /about/
---

mfp is mfp. I'm making this spot to study some technological details, 
and for fun. To there's not much I've to say. 
Please, don't take it serious.

<img src="/resources/mfp19.jpg" style="float:right;width:150px">

